# Epic Auto Combat (client-side addon for Epic Fight)

Minecraft 1.20.1 / Forge 47.x / Epic Fight 20.x. Only you need it; server and other players do not.

## Build on GitHub (no setup needed)
Push this folder to a GitHub repo. The workflow in `.github/workflows/build.yml` builds the jar automatically:
- open the repo -> **Actions** -> latest run -> download the artifact `epic-auto-combat-jar`
- or push a tag like `v1.0.0` and the jar is attached to a GitHub Release.

## Build on your PC
1. Install JDK 17.
2. Get a Gradle wrapper: copy `gradlew`, `gradlew.bat` and the `gradle/` folder from the official
   Forge 1.20.1 MDK into this folder (or run `gradle wrapper --gradle-version 8.1.1`).
3. `./gradlew build`  ->  `build/libs/epic-auto-combat-1.0.0.jar`
4. Put the jar in your `mods/` folder next to Epic Fight.

No Epic Fight jar is needed to build: it is accessed by reflection (`EpicBridge.java`).

## Use
- `V` toggles Auto Combat, `J` opens the settings screen (rebindable in Controls).
  The settings screen is also reachable from the Mods list (Config button).
- Parry needs a guard-capable weapon in your main hand. Dodge needs your Epic Fight dodge skill ready.

## Tuning for accuracy
Timing is predicted from Epic Fight's own animation data (time until the damage phase), converted to
real time and corrected for your ping.

| Symptom | Fix |
|---|---|
| Guard goes up too late / hit lands first | raise **Parry lead** (+10 ms steps) |
| Guard goes up too early / no parry window | lower **Parry lead** |
| Dodge too late or too early | change **Dodge lead** the same way |
| Everything slightly off on a server | use **Offset** (negative = earlier) |
| Reacts to enemies that aren't aiming at you | lower **Attack cone** |
| Reacts from too far away | lower **Parry range / Dodge range** |

Turn on **Debug log** and check `logs/latest.log` for lines starting with `[AutoCombat]`.
If nothing ever triggers, the log tells you which Epic Fight lookup failed.
