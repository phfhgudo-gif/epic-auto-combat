package com.autocombat;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ACConfig {

    public enum Mode {
        SMART("Smart"),
        PARRY_ONLY("Parry only"),
        DODGE_ONLY("Dodge only");

        public final String label;

        Mode(String label) {
            this.label = label;
        }
    }

    public enum DodgeDir {
        AUTO("Sideways"),
        BACKWARD("Backward"),
        KEEP_INPUT("My input");

        public final String label;

        DodgeDir(String label) {
            this.label = label;
        }
    }

    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLED, AUTO_PARRY, AUTO_DODGE, SHOW_HUD, TARGET_PLAYERS, DEBUG;
    public static final ForgeConfigSpec.EnumValue<Mode> MODE;
    public static final ForgeConfigSpec.EnumValue<DodgeDir> DODGE_DIR;
    public static final ForgeConfigSpec.DoubleValue DETECT_RANGE, PARRY_RANGE, DODGE_RANGE, ATTACK_CONE;
    public static final ForgeConfigSpec.IntValue PARRY_LEAD_MS, DODGE_LEAD_MS, EXTRA_DELAY_MS, MIN_STAMINA_PCT;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("general");

        ENABLED = b.comment("Master switch").define("enabled", true);
        AUTO_PARRY = b.comment("Automatically raise guard so the hit becomes a parry").define("autoParry", true);
        AUTO_DODGE = b.comment("Automatically dodge incoming attacks").define("autoDodge", true);
        MODE = b.comment("SMART = parry when possible, otherwise dodge").defineEnum("mode", Mode.SMART);
        DODGE_DIR = b.comment("Direction used for auto dodge").defineEnum("dodgeDirection", DodgeDir.AUTO);
        SHOW_HUD = b.define("showHud", true);
        TARGET_PLAYERS = b.comment("React to attacks from other players too (off by default)").define("targetPlayers", false);
        DEBUG = b.comment("Log every decision to the game log").define("debug", false);

        b.pop();
        b.push("range");

        DETECT_RANGE = b.comment("Only look at entities this close (blocks)")
                .defineInRange("detectRange", 8.0, 3.0, 16.0);
        PARRY_RANGE = b.comment("Parry only if the attacker is closer than this (blocks, edge to edge)")
                .defineInRange("parryRange", 3.5, 1.0, 8.0);
        DODGE_RANGE = b.comment("Dodge only if the attacker is closer than this (blocks, edge to edge)")
                .defineInRange("dodgeRange", 4.5, 1.0, 10.0);
        ATTACK_CONE = b.comment("Ignore attackers whose body is turned more than this many degrees away from you")
                .defineInRange("attackCone", 75.0, 20.0, 180.0);

        b.pop();
        b.push("timing");

        PARRY_LEAD_MS = b.comment("How long before impact the guard input should be processed (ms)")
                .defineInRange("parryLeadMs", 100, 0, 400);
        DODGE_LEAD_MS = b.comment("How long before impact the dodge input should be processed (ms)")
                .defineInRange("dodgeLeadMs", 150, 0, 600);
        EXTRA_DELAY_MS = b.comment("Fine tuning. Positive = react later, negative = react earlier (ms)")
                .defineInRange("timingOffsetMs", 0, -150, 150);
        MIN_STAMINA_PCT = b.comment("Do not auto dodge below this stamina percentage")
                .defineInRange("minStaminaPct", 10, 0, 100);

        b.pop();
        SPEC = b.build();
    }

    private ACConfig() {
    }
}
