package com.autocombat;

import com.mojang.logging.LogUtils;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.IExtensionPoint;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.network.NetworkConstants;
import org.slf4j.Logger;

/**
 * Epic Auto Combat - client-side addon for Epic Fight.
 * Nothing here is sent to the server: the mod only simulates the player's own key presses.
 */
@Mod(AutoCombat.MODID)
public final class AutoCombat {
    public static final String MODID = "autocombat";
    public static final Logger LOGGER = LogUtils.getLogger();

    public AutoCombat() {
        ModLoadingContext ctx = ModLoadingContext.get();

        // Client-only mod: servers without it must not reject the connection, and vice versa.
        ctx.registerExtensionPoint(IExtensionPoint.DisplayTest.class,
                () -> new IExtensionPoint.DisplayTest(() -> NetworkConstants.IGNORESERVERONLY, (remote, isServer) -> true));

        ctx.registerConfig(ModConfig.Type.CLIENT, ACConfig.SPEC);

        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::registerConfigScreen);
    }
}
