package com.autocombat;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class ClientKeys {
    public static final String CATEGORY = "key.categories.autocombat";

    public static final KeyMapping TOGGLE = new KeyMapping("key.autocombat.toggle", GLFW.GLFW_KEY_V, CATEGORY);
    public static final KeyMapping OPEN = new KeyMapping("key.autocombat.open", GLFW.GLFW_KEY_J, CATEGORY);

    private ClientKeys() {
    }
}
