package com.autocombat;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Timing model
 * ------------
 * Epic Fight tells us how many animation-seconds remain until an attack's damage phase ("contact").
 * We convert that to real time (play speed) and fire the input when
 *
 *     timeToImpact <= lead + ping + INPUT_LATENCY_MS
 *
 * - lead:  how early (ms) the game should already have processed our input (tunable per action)
 * - ping:  the server sees our input ~ping/2 late and the attacker's animation ~ping/2 early
 * - INPUT_LATENCY_MS: a key set at the end of tick N is consumed at the start of tick N+1 (~50 ms)
 *   and we only get to decide once per tick, so on average we are ~25 ms off the ideal moment.
 */
@Mod.EventBusSubscriber(modid = AutoCombat.MODID, value = Dist.CLIENT)
public final class CombatHandler {

    private enum Action {PARRY, DODGE}

    private static final double INPUT_LATENCY_MS = 75.0;
    private static final double DIRECTION_STEP_MS = 50.0; // dodge direction keys are pressed one tick before the dodge key

    private static final Map<Integer, Integer> HANDLED = new HashMap<>();
    private static long cooldownUntil;
    private static KeyMapping pendingDodgeKey;
    private static long pendingDodgeTick;
    private static boolean warnedNoDodgeKey;

    public static volatile String lastAction = "";
    public static volatile long lastActionAt;

    private CombatHandler() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent ev) {
        if (ev.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();

        while (ClientKeys.TOGGLE.consumeClick()) {
            boolean on = !ACConfig.ENABLED.get();
            ACConfig.ENABLED.set(on);
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.literal("Auto Combat: " + (on ? "ON" : "OFF")), true);
            }
        }
        while (ClientKeys.OPEN.consumeClick()) {
            mc.setScreen(new SettingsScreen(null));
        }

        InputSim.tick(mc);

        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) {
            HANDLED.clear();
            pendingDodgeKey = null;
            return;
        }

        // second half of a dodge: direction keys were pressed last tick, now press the dodge key itself
        if (pendingDodgeKey != null && InputSim.now() >= pendingDodgeTick) {
            InputSim.press(mc, pendingDodgeKey, 2, true);
            pendingDodgeKey = null;
        }

        if (!ACConfig.ENABLED.get() || mc.isPaused() || mc.screen != null || !p.isAlive() || p.isSpectator()) {
            return;
        }
        if (!EpicBridge.isAvailable() || !EpicBridge.inBattleMode(p)) {
            return;
        }
        if (System.currentTimeMillis() < cooldownUntil) {
            return;
        }

        double ping = pingMs(mc, p);
        double detect = ACConfig.DETECT_RANGE.get();
        AABB area = p.getBoundingBox().inflate(detect, 3.0, detect);
        List<LivingEntity> near = mc.level.getEntitiesOfClass(LivingEntity.class, area, en -> isCandidate(p, en));

        double bestDue = Double.MAX_VALUE;
        Action bestAction = null;
        EpicBridge.Threat bestThreat = null;
        float bestRel = 0f;

        for (LivingEntity en : near) {
            EpicBridge.Threat t = EpicBridge.read(en);
            if (t == null) {
                continue;
            }
            Integer done = HANDLED.get(en.getId());
            if (done != null && done == t.signature()) {
                continue;
            }

            double dx = p.getX() - en.getX();
            double dz = p.getZ() - en.getZ();
            double gap = Math.max(0.0, Math.sqrt(dx * dx + dz * dz) - en.getBbWidth() / 2.0 - p.getBbWidth() / 2.0);
            if (Math.abs(p.getY() - en.getY()) > 3.5) {
                continue;
            }

            // is the attacker actually turned towards us?
            float yawToUs = (float) (Mth.atan2(-dx, dz) * (180.0 / Math.PI));
            if (Math.abs(Mth.wrapDegrees(yawToUs - en.yBodyRot)) > ACConfig.ATTACK_CONE.get()) {
                continue;
            }
            // > 0: attacker is on our right, < 0: on our left, ~0: in front
            float relYaw = Mth.wrapDegrees((float) (Mth.atan2(dx, -dz) * (180.0 / Math.PI)) - p.getYRot());

            Action act = choose(p, gap, relYaw);
            if (act == null) {
                continue;
            }

            double lead = act == Action.PARRY ? ACConfig.PARRY_LEAD_MS.get() : ACConfig.DODGE_LEAD_MS.get();
            double extra = act == Action.DODGE && ACConfig.DODGE_DIR.get() != ACConfig.DodgeDir.KEEP_INPUT
                    ? DIRECTION_STEP_MS : 0.0;
            double trigger = lead + ping + INPUT_LATENCY_MS + extra;
            double tti = t.ttiMs() + ACConfig.EXTRA_DELAY_MS.get();
            if (tti > trigger) {
                continue; // not yet
            }
            double due = tti - trigger;
            if (due < bestDue) {
                bestDue = due;
                bestAction = act;
                bestThreat = t;
                bestRel = relYaw;
            }
        }

        if (bestThreat != null) {
            perform(mc, p, bestAction, bestThreat, bestRel, ping);
        }
        if (HANDLED.size() > 128) {
            HANDLED.clear();
        }
    }

    // ------------------------------------------------------------------ decisions

    private static boolean isCandidate(LocalPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive()) {
            return false;
        }
        if (e instanceof Player && !ACConfig.TARGET_PLAYERS.get()) {
            return false;
        }
        if (e instanceof OwnableEntity oe && p.getUUID().equals(oe.getOwnerUUID())) {
            return false;
        }
        return !e.isAlliedTo(p);
    }

    private static Action choose(LocalPlayer p, double gap, float relYaw) {
        if (!EpicBridge.canAct(p)) {
            return null;
        }
        ACConfig.Mode mode = ACConfig.MODE.get();
        boolean wantParry = ACConfig.AUTO_PARRY.get() && mode != ACConfig.Mode.DODGE_ONLY;
        boolean wantDodge = ACConfig.AUTO_DODGE.get() && mode != ACConfig.Mode.PARRY_ONLY;

        boolean canParry = wantParry
                && gap <= ACConfig.PARRY_RANGE.get()
                && Math.abs(relYaw) <= 85.0f   // a guard only covers the front
                && canGuard(p);
        boolean staminaOk = EpicBridge.staminaPct(p) * 100.0f >= ACConfig.MIN_STAMINA_PCT.get();
        boolean canDodge = wantDodge
                && staminaOk
                && gap <= ACConfig.DODGE_RANGE.get();

        if (canParry) {
            return Action.PARRY;
        }
        return canDodge ? Action.DODGE : null;
    }

    /** Right-click guard must never eat food, place blocks or draw a bow by accident. */
    private static boolean canGuard(LocalPlayer p) {
        ItemStack s = p.getMainHandItem();
        if (s.isEmpty() || s.getItem() instanceof BlockItem) {
            return false;
        }
        UseAnim ua = s.getUseAnimation();
        if (ua != UseAnim.NONE && ua != UseAnim.BLOCK) {
            return false;
        }
        return EpicBridge.isWeapon(s);
    }

    // ------------------------------------------------------------------ acting

    private static void perform(Minecraft mc, LocalPlayer p, Action act, EpicBridge.Threat t, float relYaw, double ping) {
        HANDLED.put(t.entity().getId(), t.signature());
        long now = System.currentTimeMillis();

        if (act == Action.PARRY) {
            InputSim.press(mc, InputSim.guardKey(mc), 6, true);
            cooldownUntil = now + 120;
        } else {
            KeyMapping dodge = InputSim.find(mc, "key.epicfight.dodge");
            if (dodge == null) {
                if (!warnedNoDodgeKey) {
                    warnedNoDodgeKey = true;
                    AutoCombat.LOGGER.warn("[AutoCombat] Epic Fight dodge key mapping 'key.epicfight.dodge' not found");
                }
                return;
            }
            if (ACConfig.DODGE_DIR.get() == ACConfig.DodgeDir.KEEP_INPUT) {
                InputSim.press(mc, dodge, 2, true);
            } else {
                KeyMapping dir = dodgeDirectionKey(mc, p, relYaw);
                InputSim.press(mc, dir, 3, false);
                pendingDodgeKey = dodge;
                pendingDodgeTick = InputSim.now() + 1;
            }
            cooldownUntil = now + 450;
        }

        lastAction = (act == Action.PARRY ? "PARRY" : "DODGE");
        lastActionAt = now;
        if (ACConfig.DEBUG.get()) {
            AutoCombat.LOGGER.info("[AutoCombat] {} vs {} anim={} tti={}ms ping={}ms rel={}",
                    lastAction, t.entity().getType(), t.animName(), Math.round(t.ttiMs()), Math.round(ping), Math.round(relYaw));
        }
    }

    private static KeyMapping dodgeDirectionKey(Minecraft mc, LocalPlayer p, float relYaw) {
        Options o = mc.options;
        if (ACConfig.DODGE_DIR.get() == ACConfig.DodgeDir.BACKWARD) {
            return o.keyDown;
        }
        // AUTO: step sideways, away from the attacker; fall back to the other side, then backwards
        boolean attackerOnRight = relYaw > 0;
        KeyMapping first = attackerOnRight ? o.keyLeft : o.keyRight;
        KeyMapping second = attackerOnRight ? o.keyRight : o.keyLeft;
        if (hasRoom(mc, p, first)) {
            return first;
        }
        if (hasRoom(mc, p, second)) {
            return second;
        }
        return o.keyDown;
    }

    /** Room to move 2.5 blocks sideways, with ground underneath (don't dodge off a cliff). */
    private static boolean hasRoom(Minecraft mc, LocalPlayer p, KeyMapping side) {
        double yaw = Math.toRadians(p.getYRot());
        double sign = side == mc.options.keyLeft ? 1.0 : -1.0;
        double vx = Math.cos(yaw) * sign * 2.5;
        double vz = Math.sin(yaw) * sign * 2.5;
        AABB box = p.getBoundingBox();
        return mc.level.noCollision(p, box.move(vx, 0, vz))
                && !mc.level.noCollision(p, box.move(vx, -1.2, vz));
    }

    private static double pingMs(Minecraft mc, LocalPlayer p) {
        ClientPacketListener cp = mc.getConnection();
        if (cp == null || mc.isLocalServer()) {
            return 0.0;
        }
        PlayerInfo info = cp.getPlayerInfo(p.getUUID());
        return info == null ? 0.0 : info.getLatency();
    }
}
