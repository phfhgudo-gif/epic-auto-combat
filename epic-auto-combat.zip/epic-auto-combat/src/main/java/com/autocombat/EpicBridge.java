package com.autocombat;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Everything that touches Epic Fight goes through here, via reflection.
 * Reason: the mod then compiles without the Epic Fight jar, and if Epic Fight renames something
 * only this file needs a fix. Turn on "debug" in the settings to see which lookups fail.
 */
public final class EpicBridge {

    /** An upcoming damage phase of an attack animation. ttiMs = real time until the hit lands. */
    public record Threat(LivingEntity entity, double ttiMs, int signature, String animName) {
    }

    private static boolean inited;
    private static boolean failed;
    private static Method getEntityPatch;
    private static Method getItemCap;
    private static Class<?> livingPatchCls;
    private static Class<?> attackAnimCls;
    private static Class<?> linkAnimCls;

    private static final Map<String, Optional<Method>> METHODS = new ConcurrentHashMap<>();
    private static final Map<String, Optional<Field>> FIELDS = new ConcurrentHashMap<>();
    private static final Set<String> LOGGED = ConcurrentHashMap.newKeySet();

    private EpicBridge() {
    }

    // ------------------------------------------------------------------ setup

    private static void init() {
        if (inited) {
            return;
        }
        inited = true;
        try {
            Class<?> caps = Class.forName("yesman.epicfight.world.capabilities.EpicFightCapabilities");
            livingPatchCls = Class.forName("yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch");
            attackAnimCls = Class.forName("yesman.epicfight.api.animation.types.AttackAnimation");
            try {
                linkAnimCls = Class.forName("yesman.epicfight.api.animation.LinkAnimation");
            } catch (ClassNotFoundException ignored) {
                linkAnimCls = null;
            }
            getEntityPatch = method(caps, "getEntityPatch", 2);
            getItemCap = method(caps, "getItemStackCapability", 1);
            if (getEntityPatch == null) {
                throw new IllegalStateException("EpicFightCapabilities.getEntityPatch not found");
            }
            AutoCombat.LOGGER.info("[AutoCombat] Epic Fight bridge ready");
        } catch (Throwable t) {
            failed = true;
            AutoCombat.LOGGER.error("[AutoCombat] Could not hook into Epic Fight - auto combat disabled", t);
        }
    }

    public static boolean isAvailable() {
        init();
        return !failed;
    }

    // ------------------------------------------------------------------ reflection helpers

    private static Method method(Class<?> c, String name, int argc) {
        return METHODS.computeIfAbsent(c.getName() + "#" + name + "#" + argc, k -> {
            for (Class<?> t = c; t != null; t = t.getSuperclass()) {
                for (Method m : t.getDeclaredMethods()) {
                    if (m.getName().equals(name) && m.getParameterCount() == argc && !m.isBridge()) {
                        try {
                            m.setAccessible(true);
                        } catch (Exception ignored) {
                            // fall through, invoke may still work for public members
                        }
                        return Optional.of(m);
                    }
                }
            }
            for (Method m : c.getMethods()) {
                if (m.getName().equals(name) && m.getParameterCount() == argc) {
                    return Optional.of(m);
                }
            }
            return Optional.empty();
        }).orElse(null);
    }

    private static Field field(Class<?> c, String name) {
        return FIELDS.computeIfAbsent(c.getName() + "#" + name, k -> {
            for (Class<?> t = c; t != null; t = t.getSuperclass()) {
                try {
                    Field f = t.getDeclaredField(name);
                    f.setAccessible(true);
                    return Optional.of(f);
                } catch (NoSuchFieldException ignored) {
                    // keep walking up
                } catch (Exception e) {
                    break;
                }
            }
            return Optional.empty();
        }).orElse(null);
    }

    private static Object call(Object target, String name, Object... args) throws Exception {
        Method m = method(target.getClass(), name, args.length);
        if (m == null) {
            throw new NoSuchMethodException(target.getClass().getName() + "#" + name + "/" + args.length);
        }
        return m.invoke(target, args);
    }

    private static float readFloat(Object target, String name) throws Exception {
        Field f = field(target.getClass(), name);
        if (f == null) {
            throw new NoSuchFieldException(target.getClass().getName() + "#" + name);
        }
        return ((Number) f.get(target)).floatValue();
    }

    private static void debugOnce(String key, String msg, Throwable t) {
        if (!ACConfig.DEBUG.get() || !LOGGED.add(key)) {
            return;
        }
        if (t != null) {
            AutoCombat.LOGGER.warn("[AutoCombat] " + msg, t);
        } else {
            AutoCombat.LOGGER.warn("[AutoCombat] " + msg);
        }
    }

    private static Object patchOf(Entity e) throws Exception {
        init();
        return failed ? null : getEntityPatch.invoke(null, e, livingPatchCls);
    }

    private static Object firstOf(Object pair) {
        for (String name : new String[]{"getFirst", "getLeft", "getKey"}) {
            Method m = method(pair.getClass(), name, 0);
            if (m != null) {
                try {
                    return m.invoke(pair);
                } catch (Exception ignored) {
                    // try the next accessor
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ attack timing

    /** Finds the AnimationPlayer that is currently running an attack (or a link into one). */
    private static Object findAnimationPlayer(Object patch) throws Exception {
        Object animator = call(patch, "getAnimator");
        if (animator == null) {
            return null;
        }

        // Strategy A: Animator#findFor(Class) -> Pair<AnimationPlayer, T>
        Method find = method(animator.getClass(), "findFor", 1);
        if (find != null) {
            try {
                Object pair = find.invoke(animator, attackAnimCls);
                Object player = pair == null ? null : firstOf(pair);
                if (player != null) {
                    return player;
                }
            } catch (Exception e) {
                debugOnce("findFor", "Animator#findFor failed, using base layer instead", e);
            }
        }

        // Strategy B: base layer's animation player (attacks and their link animations live here)
        Field baseLayer = field(animator.getClass(), "baseLayer");
        if (baseLayer != null) {
            Object layer = baseLayer.get(animator);
            if (layer != null) {
                Field ap = field(layer.getClass(), "animationPlayer");
                if (ap != null) {
                    return ap.get(layer);
                }
            }
        }
        debugOnce("noplayer:" + animator.getClass().getName(),
                "No animation player found on " + animator.getClass().getName(), null);
        return null;
    }

    /**
     * Returns the soonest damage phase of the attack the entity is currently playing, or null.
     * Time is converted to real milliseconds using the animation's play speed.
     */
    public static Threat read(LivingEntity e) {
        init();
        if (failed) {
            return null;
        }
        try {
            Object patch = patchOf(e);
            if (patch == null) {
                return null;
            }
            Object player = findAnimationPlayer(patch);
            if (player == null) {
                return null;
            }
            Object anim = call(player, "getAnimation");
            if (anim == null) {
                return null;
            }
            float elapsed = ((Number) call(player, "getElapsedTime")).floatValue();

            // Transition into the attack: add the remaining blend time, then use the attack's own timeline.
            double linkRemaining = 0;
            if (linkAnimCls != null && linkAnimCls.isInstance(anim)) {
                Object next = call(anim, "getNextAnimation");
                float total = ((Number) call(anim, "getTotalTime")).floatValue();
                linkRemaining = Math.max(0, total - elapsed);
                anim = next;
                elapsed = 0;
            }
            if (anim == null || !attackAnimCls.isInstance(anim)) {
                return null;
            }

            float speed = 1.0f;
            Method ps = method(anim.getClass(), "getPlaySpeed", 2);
            if (ps != null) {
                try {
                    Object r = ps.invoke(anim, patch, anim);
                    if (r instanceof Number n && n.floatValue() > 0.01f) {
                        speed = n.floatValue();
                    }
                } catch (Exception ex) {
                    debugOnce("playspeed", "getPlaySpeed failed, assuming 1.0", ex);
                }
            }

            Field phasesField = field(attackAnimCls, "phases");
            if (phasesField == null) {
                debugOnce("nophases", "AttackAnimation.phases not found", null);
                return null;
            }
            Object phases = phasesField.get(anim);
            int count = phases == null ? 0 : Array.getLength(phases);

            double best = Double.MAX_VALUE;
            int bestIdx = -1;
            for (int i = 0; i < count; i++) {
                float contact = readFloat(Array.get(phases, i), "contact");
                double tti = linkRemaining + (contact - elapsed) / speed; // seconds
                if (tti >= -0.03 && tti < best) {
                    best = tti;
                    bestIdx = i;
                }
            }
            if (bestIdx < 0) {
                return null;
            }
            int signature = System.identityHashCode(anim) * 31 + bestIdx;
            return new Threat(e, best * 1000.0, signature, String.valueOf(anim));
        } catch (Throwable t) {
            debugOnce("read:" + e.getType(), "Reading attack animation failed for " + e.getType(), t);
            return null;
        }
    }

    // ------------------------------------------------------------------ player state

    public static float staminaPct(LivingEntity player) {
        try {
            Object pt = patchOf(player);
            if (pt == null) {
                return 1f;
            }
            float cur = ((Number) call(pt, "getStamina")).floatValue();
            float max = ((Number) call(pt, "getMaxStamina")).floatValue();
            return max <= 0 ? 1f : cur / max;
        } catch (Throwable t) {
            return 1f;
        }
    }

    public static boolean canAct(LivingEntity player) {
        try {
            Object pt = patchOf(player);
            if (pt == null) {
                return true;
            }
            Object state = call(pt, "getEntityState");
            Object r = call(state, "canUseSkill");
            return !(r instanceof Boolean b) || b;
        } catch (Throwable t) {
            return true;
        }
    }

    public static boolean inBattleMode(LivingEntity player) {
        try {
            Object pt = patchOf(player);
            if (pt == null) {
                return true;
            }
            Method m = method(pt.getClass(), "isBattleMode", 0);
            return m == null || !(m.invoke(pt) instanceof Boolean b) || b;
        } catch (Throwable t) {
            return true;
        }
    }

    public static boolean isWeapon(ItemStack stack) {
        try {
            init();
            if (failed || getItemCap == null) {
                return true;
            }
            Object cap = getItemCap.invoke(null, stack);
            if (cap == null) {
                return true;
            }
            Object category = call(cap, "getWeaponCategory");
            return category == null || !String.valueOf(category).contains("NOT_WEAPON");
        } catch (Throwable t) {
            return true;
        }
    }
}
