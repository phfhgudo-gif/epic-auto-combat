package com.autocombat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public final class HudOverlay {

    private HudOverlay() {
    }

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (!ACConfig.SHOW_HUD.get() || mc.options.hideGui || mc.player == null) {
            return;
        }
        boolean on = ACConfig.ENABLED.get();
        String text = "Auto Combat: " + (on ? "ON" : "OFF");
        if (on) {
            text += "  [" + (ACConfig.AUTO_PARRY.get() ? "P" : "-") + (ACConfig.AUTO_DODGE.get() ? "D" : "-") + "]";
        }
        g.drawString(mc.font, text, 6, 6, on ? 0x55FF55 : 0xAAAAAA, true);

        if (on && System.currentTimeMillis() - CombatHandler.lastActionAt < 1200) {
            g.drawString(mc.font, "> " + CombatHandler.lastAction, 6, 18, 0xFFFF55, true);
        }
    }
}
