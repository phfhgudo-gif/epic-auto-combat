package com.autocombat;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Presses the player's own key mappings for a few ticks, exactly like a human would.
 * Nothing is sent to the server except the normal game actions those keys cause.
 */
public final class InputSim {

    private static long tick;
    private static final Map<KeyMapping, Long> RELEASE_AT = new HashMap<>();

    private InputSim() {
    }

    /** Client tick counter owned by this class. */
    public static long now() {
        return tick;
    }

    /** Call once per client tick (END phase) before making new decisions. */
    public static void tick(Minecraft mc) {
        tick++;
        Iterator<Map.Entry<KeyMapping, Long>> it = RELEASE_AT.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<KeyMapping, Long> en = it.next();
            if (tick >= en.getValue()) {
                // give the key back to the real keyboard/mouse state, so a key the user is physically holding stays down
                en.getKey().setDown(physicallyDown(mc, en.getKey()));
                it.remove();
            }
        }
    }

    public static void press(Minecraft mc, KeyMapping key, int ticks, boolean click) {
        if (key == null) {
            return;
        }
        key.setDown(true);
        if (click) {
            KeyMapping.click(key.getKey());
        }
        RELEASE_AT.merge(key, tick + ticks, Math::max);
    }

    public static KeyMapping find(Minecraft mc, String translationKey) {
        for (KeyMapping k : mc.options.keyMappings) {
            if (k.getName().equals(translationKey)) {
                return k;
            }
        }
        return null;
    }

    /** Epic Fight's own guard key when it exists, otherwise vanilla "use item" (right click). */
    public static KeyMapping guardKey(Minecraft mc) {
        KeyMapping ef = find(mc, "key.epicfight.guard");
        return ef != null ? ef : mc.options.keyUse;
    }

    private static boolean physicallyDown(Minecraft mc, KeyMapping key) {
        InputConstants.Key k = key.getKey();
        long window = mc.getWindow().getWindow();
        return switch (k.getType()) {
            case KEYSYM -> InputConstants.isKeyDown(window, k.getValue());
            case MOUSE -> GLFW.glfwGetMouseButton(window, k.getValue()) == GLFW.GLFW_PRESS;
            default -> false;
        };
    }
}
