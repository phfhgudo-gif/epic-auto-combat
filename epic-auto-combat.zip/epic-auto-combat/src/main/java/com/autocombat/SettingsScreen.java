package com.autocombat;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Hub-style settings screen: dark rounded window, category tabs on the left,
 * rows with toggles / sliders / dropdowns on the right. Every change is saved to the config immediately.
 */
public class SettingsScreen extends Screen {

    private static final int BG = 0xF2121216;
    private static final int SIDE = 0xF2181820;
    private static final int BOX = 0xFF1B1B22;
    private static final int LINE = 0xFF2B2B34;
    private static final int SEL = 0xFF2A2A35;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF8D8D99;
    private static final int ACCENT = 0xFF5B6CFF;
    private static final int OFF = 0xFF4A4A54;
    private static final int GREEN = 0xFF34C759;

    private static final int HEADER_H = 34;
    private static final int ROW_H = 30;

    private record Tab(String section, String name, String letter, int color, String title, String desc, List<Row> rows) {
    }

    private final Screen parent;
    private final List<Tab> tabs = new ArrayList<>();
    private int selected;
    private int scroll;
    private int maxScroll;
    private Row activeRow;

    // layout (computed in init)
    private int px, py, pw, ph, sideW, cx, cw, contentTop, contentBottom;
    private int[] tabY = new int[0];

    public SettingsScreen(Screen parent) {
        super(Component.literal("Epic Auto Combat"));
        this.parent = parent;
        buildTabs();
    }

    private void buildTabs() {
        tabs.add(new Tab("Auto Combat", "Parry", "P", 0xFF34C759, "Auto Parry",
                "Raises your guard just before a hit lands.", List.of(
                new ToggleRow("Enabled", "Turn auto parry on or off.", ACConfig.AUTO_PARRY),
                new SliderRow("Block range", "Only parry attackers closer than this.", 1, 8, 0.25, " m",
                        () -> ACConfig.PARRY_RANGE.get(), v -> ACConfig.PARRY_RANGE.set(v)))));

        tabs.add(new Tab("Auto Combat", "Dodge", "D", 0xFFFF375F, "Auto Dodge",
                "Dodges attacks you cannot or should not block.", List.of(
                new ToggleRow("Enabled", "Turn auto dodge on or off.", ACConfig.AUTO_DODGE),
                new ChoiceRow<>("Direction", "Where the dodge goes.", ACConfig.DodgeDir.values(),
                        () -> ACConfig.DODGE_DIR.get(), v -> ACConfig.DODGE_DIR.set(v), d -> d.label),
                new SliderRow("Dodge range", "Only dodge attackers closer than this.", 1, 10, 0.25, " m",
                        () -> ACConfig.DODGE_RANGE.get(), v -> ACConfig.DODGE_RANGE.set(v)),
                new SliderRow("Min stamina", "Do not dodge below this stamina.", 0, 100, 5, " %",
                        () -> ACConfig.MIN_STAMINA_PCT.get(), v -> ACConfig.MIN_STAMINA_PCT.set((int) Math.round(v))))));

        tabs.add(new Tab("Combat", "Targeting", "T", 0xFFAF52DE, "Targeting",
                "Which attacks count as a threat.", List.of(
                new SliderRow("Detect range", "Entities farther than this are ignored.", 3, 16, 0.5, " m",
                        () -> ACConfig.DETECT_RANGE.get(), v -> ACConfig.DETECT_RANGE.set(v)),
                new SliderRow("Attack cone", "Ignore attackers facing away more than this.", 20, 180, 5, "\u00B0",
                        () -> ACConfig.ATTACK_CONE.get(), v -> ACConfig.ATTACK_CONE.set(v)),
                new ToggleRow("Target players", "React to other players too.", ACConfig.TARGET_PLAYERS))));

        tabs.add(new Tab("Combat", "Timing", "M", 0xFFFF9F0A, "Timing",
                "How early the input is processed before impact.", List.of(
                new SliderRow("Parry lead", "Guard input before the hit.", 0, 400, 10, " ms",
                        () -> ACConfig.PARRY_LEAD_MS.get(), v -> ACConfig.PARRY_LEAD_MS.set((int) Math.round(v))),
                new SliderRow("Dodge lead", "Dodge input before the hit.", 0, 600, 10, " ms",
                        () -> ACConfig.DODGE_LEAD_MS.get(), v -> ACConfig.DODGE_LEAD_MS.set((int) Math.round(v))),
                new SliderRow("Offset", "Fine tune. Positive = later.", -150, 150, 5, " ms",
                        () -> ACConfig.EXTRA_DELAY_MS.get(), v -> ACConfig.EXTRA_DELAY_MS.set((int) Math.round(v))))));

        tabs.add(new Tab("General", "General", "G", 0xFF0A84FF, "General",
                "Master switch and misc options.", List.of(
                new ToggleRow("Auto Combat", "Master switch (hotkey V).", ACConfig.ENABLED),
                new ChoiceRow<>("Mode", "Smart parries first, else dodges.", ACConfig.Mode.values(),
                        () -> ACConfig.MODE.get(), v -> ACConfig.MODE.set(v), m -> m.label),
                new ToggleRow("HUD", "Show status in the corner.", ACConfig.SHOW_HUD),
                new ToggleRow("Debug log", "Log every decision to latest.log.", ACConfig.DEBUG))));
    }

    // ------------------------------------------------------------------ layout

    @Override
    protected void init() {
        pw = Math.min(this.width - 16, 420);
        ph = Math.min(this.height - 16, 250);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
        sideW = Mth.clamp(pw / 3, 100, 124);
        cx = px + sideW + 8;
        cw = pw - sideW - 16;
        contentTop = py + 32;
        contentBottom = py + ph - 8;

        tabY = new int[tabs.size()];
        int y = py + 40;
        String last = "";
        for (int i = 0; i < tabs.size(); i++) {
            Tab t = tabs.get(i);
            if (!t.section().equals(last)) {
                y += 15; // section label
                last = t.section();
            }
            tabY[i] = y;
            y += 22;
        }
    }

    // ------------------------------------------------------------------ drawing helpers

    private static void rrect(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x + 2, y, x + w - 2, y + h, c);
        g.fill(x, y + 2, x + w, y + h - 2, c);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, c);
    }

    private static void small(GuiGraphics g, Font f, String s, int x, int y, int color) {
        g.pose().pushPose();
        g.pose().scale(0.75f, 0.75f, 1.0f);
        g.drawString(f, s, (int) (x / 0.75f), (int) (y / 0.75f), color, false);
        g.pose().popPose();
    }

    private static boolean inRect(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        g.fill(0, 0, this.width, this.height, 0x88000000);

        // window + sidebar
        rrect(g, px, py, pw, ph, BG);
        g.fill(px + 1, py + 2, px + sideW, py + ph - 2, SIDE);
        g.fill(px + sideW, py + 1, px + sideW + 1, py + ph - 1, LINE);

        // logo
        rrect(g, px + 8, py + 8, 22, 22, ACCENT);
        g.drawCenteredString(this.font, "EA", px + 19, py + 15, WHITE);
        g.drawString(this.font, "Auto Combat", px + 36, py + 10, WHITE, false);
        small(g, this.font, "Epic Fight addon", px + 36, py + 21, GRAY);

        // tabs
        String last = "";
        for (int i = 0; i < tabs.size(); i++) {
            Tab t = tabs.get(i);
            if (!t.section().equals(last)) {
                small(g, this.font, t.section(), px + 10, tabY[i] - 13, GRAY);
                last = t.section();
            }
            boolean hover = inRect(mx, my, px + 6, tabY[i], sideW - 12, 20);
            if (i == selected) {
                rrect(g, px + 6, tabY[i], sideW - 12, 20, SEL);
            } else if (hover) {
                rrect(g, px + 6, tabY[i], sideW - 12, 20, 0x30FFFFFF);
            }
            rrect(g, px + 10, tabY[i] + 3, 14, 14, t.color());
            g.drawCenteredString(this.font, t.letter(), px + 17, tabY[i] + 6, WHITE);
            g.drawString(this.font, t.name(), px + 30, tabY[i] + 6, WHITE, false);
        }

        // footer: player + master switch
        int fy = py + ph - 30;
        rrect(g, px + 6, fy, sideW - 12, 24, SEL);
        String name = this.minecraft != null ? this.minecraft.getUser().getName() : "Player";
        g.drawString(this.font, this.font.plainSubstrByWidth(name, sideW - 24), px + 12, fy + 3, WHITE, false);
        boolean on = ACConfig.ENABLED.get();
        small(g, this.font, on ? "Auto Combat: ON" : "Auto Combat: OFF", px + 12, fy + 14, on ? GREEN : GRAY);

        // top bar: breadcrumb + window dots
        Tab tab = tabs.get(selected);
        String crumb = tab.section() + " > ";
        g.drawString(this.font, crumb, cx + 2, py + 10, GRAY, false);
        g.drawString(this.font, tab.name(), cx + 2 + this.font.width(crumb), py + 10, WHITE, false);
        rrect(g, px + pw - 48, py + 10, 8, 8, 0xFFFF5F57);
        rrect(g, px + pw - 32, py + 10, 8, 8, 0xFFFEBC2E);
        rrect(g, px + pw - 16, py + 10, 8, 8, 0xFF28C840);
        g.fill(px + sideW + 1, py + 26, px + pw - 1, py + 27, LINE);

        // scrolling content
        int viewH = contentBottom - contentTop;
        int total = HEADER_H + tab.rows().size() * ROW_H + 6;
        maxScroll = Math.max(0, total - viewH);
        scroll = Mth.clamp(scroll, 0, maxScroll);

        g.enableScissor(cx - 2, contentTop, cx + cw + 6, contentBottom);
        int y = contentTop - scroll;
        rrect(g, cx, y + 3, 20, 20, tab.color());
        g.drawCenteredString(this.font, tab.letter(), cx + 10, y + 9, WHITE);
        g.drawString(this.font, tab.title(), cx + 28, y + 4, WHITE, false);
        small(g, this.font, tab.desc(), cx + 28, y + 16, GRAY);

        int boxY = y + HEADER_H;
        int boxH = tab.rows().size() * ROW_H;
        rrect(g, cx, boxY, cw, boxH, LINE);
        rrect(g, cx + 1, boxY + 1, cw - 2, boxH - 2, BOX);
        for (int i = 0; i < tab.rows().size(); i++) {
            int ry = boxY + i * ROW_H;
            if (i > 0) {
                g.fill(cx + 8, ry, cx + cw - 8, ry + 1, LINE);
            }
            if (inRect(mx, my, cx, ry, cw, ROW_H) && my >= contentTop && my < contentBottom) {
                g.fill(cx + 1, ry + 1, cx + cw - 1, ry + ROW_H - 1, 0x10FFFFFF);
            }
            tab.rows().get(i).render(g, this.font, cx, ry, cw, mx, my);
        }
        g.disableScissor();

        if (maxScroll > 0) {
            int bar = Math.max(12, viewH * viewH / total);
            int by = contentTop + (viewH - bar) * scroll / maxScroll;
            g.fill(cx + cw + 3, by, cx + cw + 5, by + bar, OFF);
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 || button == 1) {
            if (inRect(mx, my, px + pw - 48, py + 10, 8, 8)) {
                onClose();
                return true;
            }
            for (int i = 0; i < tabs.size(); i++) {
                if (inRect(mx, my, px + 6, tabY[i], sideW - 12, 20)) {
                    selected = i;
                    scroll = 0;
                    return true;
                }
            }
            if (inRect(mx, my, px + 6, py + ph - 30, sideW - 12, 24)) {
                ACConfig.ENABLED.set(!ACConfig.ENABLED.get());
                return true;
            }
            if (inRect(mx, my, cx, contentTop, cw, contentBottom - contentTop)) {
                Tab tab = tabs.get(selected);
                int boxY = contentTop - scroll + HEADER_H;
                if (my >= boxY) {
                    int idx = (int) ((my - boxY) / ROW_H);
                    if (idx >= 0 && idx < tab.rows().size()) {
                        Row r = tab.rows().get(idx);
                        if (r.click(mx, my, button)) {
                            activeRow = r;
                        }
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (activeRow != null) {
            activeRow.drag(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        activeRow = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll = Mth.clamp(scroll - (int) (delta * 14), 0, maxScroll);
        return true;
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(parent);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ rows

    private abstract static class Row {
        final String title;
        final String desc;
        int rx, ry, rw;

        Row(String title, String desc) {
            this.title = title;
            this.desc = desc;
        }

        abstract int controlWidth();

        abstract void control(GuiGraphics g, Font f, int mx, int my);

        /** @return true if the row wants to receive drag events (sliders) */
        boolean click(double mx, double my, int button) {
            return false;
        }

        void drag(double mx) {
        }

        void render(GuiGraphics g, Font f, int x, int y, int w, int mx, int my) {
            this.rx = x;
            this.ry = y;
            this.rw = w;
            g.drawString(f, title, x + 10, y + 5, WHITE, false);
            int maxPx = (int) ((w - 24 - controlWidth()) / 0.75f);
            small(g, f, f.plainSubstrByWidth(desc, Math.max(20, maxPx)), x + 10, y + 17, GRAY);
            control(g, f, mx, my);
        }
    }

    private static final class ToggleRow extends Row {
        private final ForgeConfigSpec.BooleanValue value;

        ToggleRow(String title, String desc, ForgeConfigSpec.BooleanValue value) {
            super(title, desc);
            this.value = value;
        }

        @Override
        int controlWidth() {
            return 30;
        }

        @Override
        void control(GuiGraphics g, Font f, int mx, int my) {
            boolean on = value.get();
            int tx = rx + rw - 10 - 26;
            int ty = ry + 9;
            rrect(g, tx, ty, 26, 12, on ? ACCENT : OFF);
            rrect(g, on ? tx + 15 : tx + 3, ty + 2, 8, 8, WHITE);
        }

        @Override
        boolean click(double mx, double my, int button) {
            value.set(!value.get());
            return false;
        }
    }

    private static final class SliderRow extends Row {
        private static final int TRACK_W = 70;
        private final double min;
        private final double max;
        private final double step;
        private final String unit;
        private final DoubleSupplier getter;
        private final DoubleConsumer setter;

        SliderRow(String title, String desc, double min, double max, double step, String unit,
                  DoubleSupplier getter, DoubleConsumer setter) {
            super(title, desc);
            this.min = min;
            this.max = max;
            this.step = step;
            this.unit = unit;
            this.getter = getter;
            this.setter = setter;
        }

        @Override
        int controlWidth() {
            return 130;
        }

        private int trackX() {
            return rx + rw - 12 - TRACK_W;
        }

        private String format(double v) {
            return (step >= 1.0 ? String.valueOf((int) Math.round(v)) : String.format(Locale.ROOT, "%.2f", v)) + unit;
        }

        @Override
        void control(GuiGraphics g, Font f, int mx, int my) {
            double val = getter.getAsDouble();
            double t = Mth.clamp((val - min) / (max - min), 0.0, 1.0);
            int tx = trackX();
            int ty = ry + 14;
            int filled = (int) (TRACK_W * t);
            g.fill(tx, ty, tx + TRACK_W, ty + 3, OFF);
            g.fill(tx, ty, tx + filled, ty + 3, ACCENT);
            rrect(g, tx + filled - 3, ty - 4, 6, 11, WHITE);
            String s = format(val);
            g.drawString(f, s, tx - 6 - f.width(s), ry + 11, WHITE, false);
        }

        private void setFrom(double mx) {
            double t = Mth.clamp((mx - trackX()) / TRACK_W, 0.0, 1.0);
            double v = Math.round((min + t * (max - min)) / step) * step;
            setter.accept(Mth.clamp(v, min, max));
        }

        @Override
        boolean click(double mx, double my, int button) {
            if (mx >= trackX() - 6 && mx <= trackX() + TRACK_W + 6) {
                setFrom(mx);
                return true;
            }
            return false;
        }

        @Override
        void drag(double mx) {
            setFrom(mx);
        }
    }

    /** Dropdown-looking box; left click = next option, right click = previous option. */
    private static final class ChoiceRow<T> extends Row {
        private final List<T> values;
        private final Supplier<T> getter;
        private final Consumer<T> setter;
        private final Function<T, String> label;

        ChoiceRow(String title, String desc, T[] values, Supplier<T> getter, Consumer<T> setter, Function<T, String> label) {
            super(title, desc);
            this.values = Arrays.asList(values);
            this.getter = getter;
            this.setter = setter;
            this.label = label;
        }

        @Override
        int controlWidth() {
            return 100;
        }

        @Override
        void control(GuiGraphics g, Font f, int mx, int my) {
            int bw = 92;
            int bx = rx + rw - 10 - bw;
            int by = ry + 7;
            rrect(g, bx, by, bw, 16, SEL);
            g.drawString(f, f.plainSubstrByWidth(label.apply(getter.get()), bw - 18), bx + 5, by + 4, WHITE, false);
            g.drawString(f, "v", bx + bw - 10, by + 4, GRAY, false);
        }

        @Override
        boolean click(double mx, double my, int button) {
            int n = values.size();
            int i = Math.max(0, values.indexOf(getter.get()));
            i = (i + (button == 1 ? -1 : 1) + n) % n;
            setter.accept(values.get(i));
            return false;
        }
    }
}
